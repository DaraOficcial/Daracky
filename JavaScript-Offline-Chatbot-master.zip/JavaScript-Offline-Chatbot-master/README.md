# JavaScript Offline Chatbot
It's a client side chatbot created using elasticlunar plugin.

## Features Included :

- JS light weight chatbot
- Offline chatbot
- JSON Knowledgebase 
- Interactive chat UI integration
- Usage of (elastilunar) powerful text search library 

### Preview

![alt tag](https://github.com/vishnusudarsan/JavaScript-Offline-Chatbot/blob/master/assets/images/chatbot.png "chatbot UI")


