var index = elasticlunr(function() {
  this.addField("title");
  this.addField("body");
  this.setRef("id");
});

// Dokumen pertanyaan & jawaban dalam bahasa Indonesia (50+)
var docs = [
  {id:1, title:"halo, hi, hai", body:"Halo juga! Apa kabar hari ini?"},
  {id:2, title:"terima kasih, makasih", body:"Sama-sama! Senang bisa membantu."},
  {id:3, title:"siapa kamu, kamu siapa", body:"Aku DRZ AI, chatbot offline lokal kamu. Bisa bantu ngobrol atau coding."},
  {id:4, title:"apa kabar", body:"Baik, siap bantu. Kamu sendiri gimana?"},
  {id:5, title:"cara bikin midi controller, midi controller", body:"Untuk MIDI controller, pakai Arduino Micro / Pro Micro (ATmega32u4) supaya langsung USB-MIDI, lalu tambahkan tombol, potensiometer, dan firmware sederhana."},
  {id:6, title:"convert html ke xml, html to xml", body:"Pakai DOMParser di JS atau Jsoup di Android. Aku bisa bantu bikin tool offline."},
  {id:7, title:"apa itu AI, chatbot", body:"AI atau chatbot adalah program yang bisa menjawab pertanyaan dan ngobrol layaknya manusia."},
  {id:8, title:"cuaca hari ini", body:"Aku belum bisa ambil data cuaca realtime, tapi biasanya cek di BMKG atau Google ya."},
  {id:9, title:"jam berapa sekarang", body:"Cek jam di perangkatmu, aku nggak bisa lihat jam realtime."},
  {id:10, title:"tips belajar, belajar efektif", body:"Buat jadwal rutin, fokus pada satu topik, istirahat cukup, dan praktik langsung apa yang dipelajari."},
  {id:11, title:"cara cepat tidur", body:"Hindari layar gadget sebelum tidur, tenangkan pikiran, dan atur waktu tidur rutin."},
  {id:12, title:"cara diet sehat", body:"Konsumsi makanan seimbang, hindari gula berlebihan, minum air cukup, dan olahraga rutin."},
  {id:13, title:"makanan sehat", body:"Sayur, buah, protein, dan biji-bijian adalah makanan sehat sehari-hari."},
  {id:14, title:"cara belajar coding", body:"Mulai dari dasar, praktek langsung, buat proyek kecil, dan baca dokumentasi resmi."},
  {id:15, title:"bahasa pemrograman terbaik", body:"Tergantung tujuan. Python mudah untuk AI, C++ cepat untuk game, HTML/CSS untuk web."},
  {id:16, title:"apa itu HTML, CSS, JS", body:"HTML untuk struktur, CSS untuk tampilan, JS untuk interaksi."},
  {id:17, title:"tips produktif", body:"Buat to-do list, fokus pada satu tugas, gunakan timer Pomodoro, dan istirahat cukup."},
  {id:18, title:"cara membuat website", body:"Pelajari HTML, CSS, JS. Gunakan editor dan hosting lokal/online."},
  {id:19, title:"cara membuat game", body:"Pakai engine seperti Unity/Unreal atau coding sendiri pakai C++/HTML5."},
  {id:20, title:"cara bikin OS sederhana", body:"Mulai dari belajar Buildroot atau Linux embedded, lalu buat GUI sederhana."},
  {id:21, title:"apa itu CPU, GPU", body:"CPU untuk menghitung & logika, GPU untuk grafis & operasi paralel."},
  {id:22, title:"kenapa GPU cepat", body:"Karena memiliki banyak core kecil untuk proses paralel, cocok untuk grafis & AI."},
  {id:23, title:"mikrokontroler tanpa GPU", body:"Ya bisa, tapi tidak bisa render grafis berat. Cocok untuk embedded."},
  {id:24, title:"kapan Ramadan", body:"Tanggal pasti tergantung hilal, biasanya diumumkan oleh pemerintah atau ormas terkait."},
  {id:25, title:"hari kemerdekaan Indonesia", body:"17 Agustus setiap tahun."},
  {id:26, title:"apa itu blockchain", body:"Blockchain adalah database terdesentralisasi yang aman & transparan."},
  {id:27, title:"cara beli bitcoin", body:"Lewat exchange resmi seperti Indodax, Tokocrypto, atau platform internasional."},
  {id:28, title:"tips aman internet", body:"Gunakan password kuat, jangan sembarangan klik link, update software rutin."},
  {id:29, title:"cara backup data", body:"Gunakan cloud storage, hard disk eksternal, atau NAS untuk backup rutin."},
  {id:30, title:"apa itu MIDI", body:"MIDI adalah protokol musik digital untuk komunikasi antar alat musik elektronik."},
  {id:31, title:"cara pakai Arduino", body:"Instal Arduino IDE, sambungkan board, tulis kode, dan upload."},
  {id:32, title:"apa itu microcontroller", body:"Microcontroller adalah chip komputer kecil untuk mengontrol perangkat elektronik."},
  {id:33, title:"tips hemat listrik", body:"Matikan perangkat yang tidak dipakai, gunakan LED, dan cabut charger bila tidak dipakai."},
  {id:34, title:"cara mempercepat komputer", body:"Bersihkan file sampah, uninstall software tidak perlu, upgrade RAM/SSD."},
  {id:35, title:"apa itu RAM", body:"RAM adalah memori sementara untuk menyimpan data aktif saat komputer berjalan."},
  {id:36, title:"apa itu ROM", body:"ROM adalah memori permanen yang menyimpan program dasar atau firmware."},
  {id:37, title:"cara install Windows", body:"Gunakan USB bootable, ikuti wizard instalasi, dan masukkan product key."},
  {id:38, title:"cara install Linux", body:"Buat USB bootable Linux, boot dari USB, dan ikuti panduan instalasi."},
  {id:39, title:"tips belajar bahasa Inggris", body:"Rutin membaca, menulis, mendengar, dan berbicara. Gunakan aplikasi & latihan sehari-hari."},
  {id:40, title:"cara bikin aplikasi Android", body:"Pelajari Java/Kotlin, gunakan Android Studio, buat UI & logic, lalu build APK."},
  {id:41, title:"apa itu XML", body:"XML adalah bahasa markup untuk menyimpan & memindahkan data secara terstruktur."},
  {id:42, title:"apa itu JSON", body:"JSON adalah format data ringan untuk pertukaran data, mudah dibaca manusia dan mesin."},
  {id:43, title:"tips presentasi", body:"Persiapkan materi, latihan, gunakan visual, dan bicara dengan jelas."},
  {id:44, title:"cara bikin chatbot", body:"Gunakan JS, Python, atau framework chatbot, buat KB & logika percakapan."},
  {id:45, title:"cara bikin AI offline", body:"Simpan KB lokal, gunakan JS atau Python, dan jangan perlu koneksi internet."},
  {id:46, title:"apa itu server web", body:"Server web adalah komputer/software yang menyajikan halaman web ke browser."},
  {id:47, title:"apa itu HTML5", body:"HTML5 adalah standar terbaru HTML dengan fitur multimedia & interaktivitas lebih lengkap."},
  {id:48, title:"apa itu CSS3", body:"CSS3 adalah versi terbaru CSS dengan fitur animasi, transisi, dan layout modern."},
  {id:49, title:"apa itu JavaScript", body:"JavaScript adalah bahasa scripting untuk membuat halaman web interaktif."},
  {id:50, title:"cara belajar cepat", body:"Fokus, buat catatan, latihan langsung, dan ulangi materi secara konsisten."},
  {id:51, title:"tips santai di rumah", body:"Dengarkan musik, baca buku, nonton film, atau main game santai."},
  {id:52, title:"cara tidur cepat", body:"Hindari gadget, tenangkan pikiran, tarik napas dalam, dan tidur dengan rutin."}
];

// Tambahkan semua dokumen ke index
docs.forEach(doc => index.addDoc(doc));