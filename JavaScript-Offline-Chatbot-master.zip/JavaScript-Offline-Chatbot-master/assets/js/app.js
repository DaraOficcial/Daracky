var chatReply = [];

// scroll ke bawah chat
var scrollChatbox = function() {
  $("html, body").animate({ scrollTop: $(document).height() }, 300);
};

// tampilkan pertanyaan user
var userQuestionBuilder = function(msg, time) {
  $(".chat").append(
    "<li class='self'><div class='avatar'>" +
      "<img src='./assets/images/user.png' draggable='false' />" +
      "</div><div class='msg'><p>" +
      escapeHtml(msg) +
      "</p><time>" +
      time +
      "</time></div></li>"
  );
  scrollChatbox();
};

// tampilkan jawaban bot
var replyProvider = function(reply) {
  var today = new Date(),
      time = today.getHours() + ":" + String(today.getMinutes()).padStart(2,"0");

  $(".chat").append(
    "<li class='other'><div class='avatar'>" +
      "<img src='./assets/images/bot.png' draggable='false' />" +
      "</div><div class='msg'><p>" +
      escapeHtml(reply) +
      "</p><time>" +
      time +
      "</time></div></li>"
  );
  scrollChatbox();
};

// normalisasi string untuk pencocokan
function norm(s){ return s.toLowerCase().replace(/[^\w\s]/g,'').trim(); }

// fuzzy similarity (Levenshtein)
function levenshtein(a,b){
  a=a.toLowerCase(); b=b.toLowerCase();
  const m=a.length,n=b.length;
  if(!m) return n;if(!n) return m;
  const dp=Array.from({length:m+1},()=>Array(n+1).fill(0));
  for(let i=0;i<=m;i++) dp[i][0]=i;
  for(let j=0;j<=n;j++) dp[0][j]=j;
  for(let i=1;i<=m;i++) for(let j=1;j<=n;j++){
    dp[i][j]=Math.min(dp[i-1][j]+1, dp[i][j-1]+1, dp[i-1][j-1]+(a[i-1]===b[j-1]?0:1));
  }
  return dp[m][n];
}
function similarity(a,b){ const d=levenshtein(a,b); return 1 - d/Math.max(a.length,b.length||1); }

// ambil jawaban dari KB (ElasticLunr + fallback)
function answerFromKB(input){
  const t = input.toLowerCase().trim();
  if(t.length < 2) return "Maaf bro, aku belum paham. Bisa tulis kata lengkap?";

  // exact match
  for(const it of docs){
    for(const q of it.title.split(",")){
      if(t === q.toLowerCase().trim()) return it.body;
    }
  }

  // fuzzy match
  let best = {score:0, ans:null};
  for(const it of docs){
    for(const q of it.title.split(",")){
      const sim = similarity(t, q.toLowerCase().trim());
      if(sim > best.score) best = {score:sim, ans:it.body};
    }
  }

  if(best.score >= 0.65) return best.ans; // hanya kalau cukup mirip

  // fallback
  return "Maaf bro, aku belum paham. Bisa tulis kata lengkap?";
}

// inisialisasi response
var initResponse = function() {
  var input = $("#chat-question").val().trim();
  var time = new Date().getHours() + ":" + String(new Date().getMinutes()).padStart(2,"0");

  if(input.length < 2){
    userQuestionBuilder(input, time);
    replyProvider("Maaf bro, aku belum paham. Bisa tulis kata lengkap?");
    $("#chat-question").val("");
    return;
  }

  // 1. Exact match
  let exactAnswer = null;
  for(const doc of docs){
    for(const q of doc.title.split(",")){
      if(input.toLowerCase() === q.toLowerCase().trim()){
        exactAnswer = doc.body;
        break;
      }
    }
    if(exactAnswer) break;
  }

  userQuestionBuilder(input, time);

  if(exactAnswer){
    replyProvider(exactAnswer);
  } else {
    // 2. Fuzzy match dengan threshold ketat
    let best = {score:0, ans:null};
    for(const doc of docs){
      for(const q of doc.title.split(",")){
        const sim = similarity(input.toLowerCase(), q.toLowerCase().trim());
        if(sim > best.score) best = {score:sim, ans:doc.body};
      }
    }
    if(best.score >= 0.75){
      replyProvider(best.ans);
    } else {
      // 3. fallback
      replyProvider("Maaf bro, aku belum paham. Bisa tulis kata lengkap?");
    }
  }

  $("#chat-question").val("");
};

// escape html untuk keamanan
function escapeHtml(s){ return s.replace(/[&<>"']/g, c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;','\'':'&apos;'}[c])); }

$(document).ready(function() {
  $("#ask-question").click(function() {
    initResponse();
  });

  $("#chat-question").keypress(function(event) {
    if (event.which == 13) {
      event.preventDefault();
      initResponse();
    }
  });
});